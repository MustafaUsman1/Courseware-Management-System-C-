class CourseAdministrator
{
    public:
    
    //virtual void viewCourse() =0;

    void viewCourse(){};
    void manageCourse(){};
    void manageTopic(){};
    void viewCourseCalender(){};
    void viewTutor(){};
    void manageTutorInformation(){};
    void assignTutortoCourse(){};

};

class Student{

    public:
    void viewallstudents(){};
    void viewstudentInfortmation(){};
};


class CourseCalender
{
    public:
    
    void viewCourseCalender( Student s1, CourseAdministrator c1)
    {}
};

class Tutor
{
    CourseAdministrator C1;
    public:

    void viewTutorInformation(CourseAdministrator t1){};
    void createTutor(CourseAdministrator t1){};
    void modifyTutor(CourseAdministrator t2){};
    void removeTutor(CourseAdministrator t3){};

};


class Topic
{
    CourseAdministrator C1;
    void viewAllTopic(CourseAdministrator c1){};
    void viewTopicInformation(CourseAdministrator c1){};
    void createTopic(CourseAdministrator c1){};
    void modifyTopic(CourseAdministrator c2){};
    void removeTopic(CourseAdministrator c3){};
};

class Course
{
    Topic t1;
    CourseAdministrator t2;
    void viewAllcourse(){};
    void viewcourseInformation(){};
    void createcourse(){};
    void modifycourse(){};
    void removecourse(){};
};